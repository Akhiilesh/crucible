# orders-service: Crucible demo repository

A small FastAPI orders service with three open pull requests. **Bugs were planted on purpose.**

| Branch | Pull request |
|---|---|
| `pr-1-refunds` | Refund endpoint |
| `pr-2-discounts` | Discount endpoint |
| `pr-3-bulk-cancel` | Bulk cancel endpoint |

`runs/<branch>/` holds IBM Bob's attacker output for each PR (intent, 4 lenses of findings and their
pytest proof tests), produced with Crucible's `.bob/playbook/`.

Upload this repo (zip including `.git`) in Crucible's web app, choose base `main`, a PR branch and the
matching `runs/<branch>` folder, then run the proof gates.
